rpc is a msgpack-rpc library for modern C++. The goal of this library is to provide a simple, no-nonsense RPC solution. This installs its headers and binaries to the system.


